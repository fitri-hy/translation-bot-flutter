Run .exe file:
`x64\runner\Release\translation.exe`